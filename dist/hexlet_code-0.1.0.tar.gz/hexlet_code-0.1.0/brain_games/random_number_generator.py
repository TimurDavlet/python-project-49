import random


def random_integer(min=1, max=100):
    return random.randint(min, max)
