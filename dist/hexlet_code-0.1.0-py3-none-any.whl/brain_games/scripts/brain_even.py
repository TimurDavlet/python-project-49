#!/usr/bin/env python3
from brain_games import brain_even


def hello():
    print('Welcome to the Brain Games!')


def main():
    hello()
    brain_even.even_game()


if __name__ == '__main__':
    main()
